Hello! This is a guide on how to run the program! - Aditya Khanna and Kedar Raman (ak34642 and kvr336)

1) Unzip the folder and extract all of the files
2) Compile the code with your own driver.cpp (driver.cpp and BST312.h)
3) Run the executable
4) The program will run a BST program. 